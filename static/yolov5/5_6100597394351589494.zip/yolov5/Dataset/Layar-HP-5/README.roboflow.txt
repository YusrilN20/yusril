
Layar HP - v5 Part 4-Revisi Label-
==============================

This dataset was exported via roboflow.ai on May 24, 2022 at 1:27 PM GMT

It includes 1031 images.
Kerusakan-pada-layarHP are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (black edges))
* Auto-contrast via adaptive equalization

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down


