# undefined > Part 4-Revisi Label-
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

undefined